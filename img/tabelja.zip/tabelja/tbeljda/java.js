
let currentRow = null;

document.addEventListener('DOMContentLoaded', function () {
    loadStudents();
});

document.getElementById('studentForm').addEventListener('submit', function (event) {
    event.preventDefault();

    const name = document.getElementById('nameId').value;
    const age = document.getElementById('ageId').value;
    const city = document.getElementById('cityId').value;
    const country = document.getElementById('countryId').value;
    const email = document.getElementById('emailId').value;
    const phone = document.getElementById('phoneId').value;

    if (currentRow) {
        currentRow.cells[1].textContent = name;
        currentRow.cells[2].textContent = age;
        currentRow.cells[3].textContent = city;
        currentRow.cells[4].textContent = country;
        currentRow.cells[5].textContent = email;
        currentRow.cells[6].textContent = phone;

        updateStudentInStorage(currentRow.rowIndex - 1, { name, age, city, country, email, phone });

        currentRow = null;
    } else {
        const tableBody = document.getElementById('studentTableBody');
        const newRow = document.createElement('tr');

        const cellId = document.createElement('td');
        cellId.textContent = tableBody.rows.length + 1;

        const cellName = document.createElement('td');
        cellName.textContent = name;

        const cellAge = document.createElement('td');
        cellAge.textContent = age;

        const cellCity = document.createElement('td');
        cellCity.textContent = city;

        const cellCountry = document.createElement('td');
        cellCountry.textContent = country;

        const cellEmail = document.createElement('td');
        cellEmail.textContent = email;

        const cellPhone = document.createElement('td');
        cellPhone.textContent = phone;

        const cellActions = document.createElement('td');

        const deleteButton = document.createElement('button');
        deleteButton.textContent = 'Delete';
        deleteButton.addEventListener('click', function () {
            tableBody.removeChild(newRow);
            deleteStudentFromStorage(newRow.rowIndex - 1);
            updateRowIds();
        });

        const editButton = document.createElement('button');
        editButton.textContent = 'Edit';
        editButton.addEventListener('click', function () {
            document.getElementById('nameId').value = name;
            document.getElementById('ageId').value = age;
            document.getElementById('cityId').value = city;
            document.getElementById('countryId').value = country;
            document.getElementById('emailId').value = email;
            document.getElementById('phoneId').value = phone;
            currentRow = newRow;
        });

        cellActions.appendChild(editButton);
        cellActions.appendChild(deleteButton);

        const cellNotat = document.createElement('td');
        const gradesButton = document.createElement('button');
        gradesButton.textContent = 'Grades';
        gradesButton.addEventListener('click', function () {
            addGradesRow(newRow, tableBody.rows.length);
        });
        cellNotat.appendChild(gradesButton);

        newRow.appendChild(cellId);
        newRow.appendChild(cellName);
        newRow.appendChild(cellAge);
        newRow.appendChild(cellCity);
        newRow.appendChild(cellCountry);
        newRow.appendChild(cellEmail);
        newRow.appendChild(cellPhone);
        newRow.appendChild(cellActions);
        newRow.appendChild(cellNotat);

        tableBody.appendChild(newRow);
        addStudentToStorage({ name, age, city, country, email, phone, grades: [] });
    }

    document.getElementById('studentForm').reset();
});

function addGradesRow(row, studentIndex) {
    if (row.nextSibling && row.nextSibling.classList.contains('grades-row')) {
        row.parentNode.removeChild(row.nextSibling);
    } else {
        const gradesRow = document.createElement('tr');
        gradesRow.classList.add('grades-row');
        const gradesCell = document.createElement('td');
        gradesCell.colSpan = 9;

        const subjects = ['Math', 'Gjuhe', 'Histori', 'Gjeografi', 'Chemistry', 'English', 'Physics'];
        const students = JSON.parse(localStorage.getItem('students')) || [];
        const student = students[studentIndex];
        const grades = student.grades.length > 0 ? student.grades : [4, 3, 1, 5, 2, 3, 2];

        const gradesTable = document.createElement('table');
        gradesTable.style.width = '100%';
        gradesTable.style.borderCollapse = 'collapse';

        subjects.forEach((subject, index) => {
            const subjectRow = document.createElement('tr');

            const subjectCell = document.createElement('td');
            subjectCell.textContent = subject;
            subjectCell.style.border = '1px solid black';
            subjectCell.style.padding = '5px';

            const gradeCell = document.createElement('td');
            gradeCell.textContent = grades[index];
            gradeCell.style.border = '1px solid black';
            gradeCell.style.padding = '5px';

            subjectRow.appendChild(subjectCell);
            subjectRow.appendChild(gradeCell);
            gradesTable.appendChild(subjectRow);
        });

        const editGradesButton = document.createElement('button');
        editGradesButton.textContent = 'Edit Grades';
        editGradesButton.addEventListener('click', function () {
            editGrades(gradesTable, subjects, gradesRow, studentIndex);
        });

        gradesCell.appendChild(gradesTable);
        gradesCell.appendChild(editGradesButton);
        gradesRow.appendChild(gradesCell);

        row.parentNode.insertBefore(gradesRow, row.nextSibling);
    }
}

function editGrades(gradesTable, subjects, gradesRow, studentIndex) {
    const gradeCells = gradesTable.querySelectorAll('td:nth-child(2)');
    gradeCells.forEach((cell, index) => {
        const input = document.createElement('input');
        input.type = 'number';
        input.value = cell.textContent;
        input.style.width = '100%';
        cell.textContent = '';
        cell.appendChild(input);
    });

    const saveGradesButton = document.createElement('button');
    saveGradesButton.textContent = 'Save Grades';
    saveGradesButton.addEventListener('click', function () {
        saveGrades(gradesTable, subjects, gradesRow, studentIndex);
    });

    const editButton = gradesRow.querySelector('button');
    editButton.parentNode.replaceChild(saveGradesButton, editButton);
}

function saveGrades(gradesTable, subjects, gradesRow, studentIndex) {
    const gradeCells = gradesTable.querySelectorAll('td:nth-child(2)');
    const newGrades = [];
    gradeCells.forEach(cell => {
        const input = cell.querySelector('input');
        newGrades.push(input.value);
        cell.textContent = input.value;
    });

    const students = JSON.parse(localStorage.getItem('students')) || [];
    students[studentIndex].grades = newGrades;
    localStorage.setItem('students', JSON.stringify(students));

    const saveButton = gradesRow.querySelector('button');
    const editGradesButton = document.createElement('button');
    editGradesButton.textContent = 'Edit Grades';
    editGradesButton.addEventListener('click', function () {
        editGrades(gradesTable, subjects, gradesRow, studentIndex);
    });

    saveButton.parentNode.replaceChild(editGradesButton, saveButton);
}

function loadStudents() {
    const students = JSON.parse(localStorage.getItem('students')) || [];
    const tableBody = document.getElementById('studentTableBody');
    students.forEach((student, index) => {
        const newRow = document.createElement('tr');

        const cellId = document.createElement('td');
        cellId.textContent = index + 1;

        const cellName = document.createElement('td');
        cellName.textContent = student.name;

        const cellAge = document.createElement('td');
        cellAge.textContent = student.age;

        const cellCity = document.createElement('td');
        cellCity.textContent = student.city;

        const cellCountry = document.createElement('td');
        cellCountry.textContent = student.country;

        const cellEmail = document.createElement('td');
        cellEmail.textContent = student.email;

        const cellPhone = document.createElement('td');
        cellPhone.textContent = student.phone;

        const cellActions = document.createElement('td');

        const deleteButton = document.createElement('button');
        deleteButton.textContent = 'Delete';
        deleteButton.addEventListener('click', function () {
            tableBody.removeChild(newRow);
            deleteStudentFromStorage(newRow.rowIndex - 1);
            updateRowIds();
        });

        const editButton = document.createElement('button');
        editButton.textContent = 'Edit';
        editButton.addEventListener('click', function () {
            document.getElementById('nameId').value = student.name;
            document.getElementById('ageId').value = student.age;
            document.getElementById('cityId').value = student.city;
            document.getElementById('countryId').value = student.country;
            document.getElementById('emailId').value = student.email;
            document.getElementById('phoneId').value = student.phone;
            currentRow = newRow;
        });

        cellActions.appendChild(editButton);
        cellActions.appendChild(deleteButton);

        const cellNotat = document.createElement('td');
        const gradesButton = document.createElement('button');
        gradesButton.textContent = 'Grades';
        gradesButton.addEventListener('click', function () {
            addGradesRow(newRow, index);
        });
        cellNotat.appendChild(gradesButton);

        newRow.appendChild(cellId);
        newRow.appendChild(cellName);
        newRow.appendChild(cellAge);
        newRow.appendChild(cellCity);
        newRow.appendChild(cellCountry);
        newRow.appendChild(cellEmail);
        newRow.appendChild(cellPhone);
        newRow.appendChild(cellActions);
        newRow.appendChild(cellNotat);

        tableBody.appendChild(newRow);
    });
}

function addStudentToStorage(student) {
    const students = JSON.parse(localStorage.getItem('students')) || [];
    students.push(student);
    localStorage.setItem('students', JSON.stringify(students));
}

function updateStudentInStorage(index, student) {
    const students = JSON.parse(localStorage.getItem('students')) || [];
    students[index] = student;
    localStorage.setItem('students', JSON.stringify(students));
}

function deleteStudentFromStorage(index) {
    const students = JSON.parse(localStorage.getItem('students')) || [];
    students.splice(index, 1);
    localStorage.setItem('students', JSON.stringify(students));
}

function updateRowIds() {
    const tableBody = document.getElementById('studentTableBody');
    for (let i = 0; i < tableBody.rows.length; i++) {
        tableBody.rows[i].cells[0].textContent = i + 1;
    }
}
